<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    Contact Page <a href="<?php echo e(url('add_contact')); ?>">Add contact</a>
                    <table border="1">
                    <tr>
                    <td>Name</td>
                    <td>Email</td>
                    <td>Phone</td>
                    <td>Address</td>
                    <td>Company</td>
                    <td>Date Of Birth</td>
                     <td>Action</td>
                    </tr>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($contact->name); ?></td>
                    <td><?php echo e($contact->email); ?></td>
                    <td><?php echo e($contact->phone); ?></td>
                    <td><?php echo e($contact->address); ?></td>
                    <td><?php echo e($contact->company); ?></td>                                                                                
                    <td><?php echo e($contact->dob); ?></td> 
                    <td><a href="<?php echo e(url('edit')); ?>/<?php echo e($contact->id); ?>">Edit </a>/ <a href="<?php echo e(url('delete')); ?>/<?php echo e($contact->id); ?>" onclick="return confirm('Are You Sure');">Delete</a></td>                    
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>